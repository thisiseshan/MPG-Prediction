import keras as k
import keras
from keras.models import Sequential
from keras.optimizers import SGD
from keras.layers import Dense, Activation, Dropout
import numpy as np
import matplotlib.pyplot as plt 
from random import randint
import json
x = list()
y = list()
def f(x):
    y = x*randint(0,10)
    return y 
with open('r.json') as myfile:
    data=myfile.read()
data = json.loads(data)
# parse file
x = []
y = []
for i in range(len(data)):
    #car = json.loads(data[i])
    car = data[i]
    if(car["Miles_per_Gallon"] is'None' or car["Miles_per_Gallon"] is None):
        continue
    if(car["Horsepower"] is None or car["Horsepower"] is 'null' or car["Cylinders"]  is None or car['Acceleration'] is None or car['Weight_in_lbs'] is None ):
        continue
    if(car["Horsepower"] != None or car["Horsepower"] != 'null' or car["Cylinders"] !=None or car['Acceleration'] != None or car['Weight_in_lbs'] != None ):
        x.append([ car["Horsepower"]])
        if(car["Miles_per_Gallon"] != 'None' or car["Miles_per_Gallon"] != None):
            print(car )
            y.append(car["Miles_per_Gallon"])
data = x
print((x))
print((y))
model = Sequential()
model.add(Dense(1, input_dim=1, use_bias=False, activation='sigmoid'))
model.add(Dense(100, activation='tanh',))
model.add(Dense(50, activation='tanh',))
model.add(Dense(25, activation='tanh',))
model.add(Dense(25, activation='tanh',))
model.add(Dense(25, activation='tanh',))
model.add(Dense(25, activation='tanh',))
model.add(Dense(1, activation='relu',))
sgd = SGD(lr=0.01, momentum=0.9, nesterov=True)
model.compile( loss = "mean_squared_error", 
               optimizer = sgd, 
               metrics=['accuracy']
             )

weights = model.layers[0].get_weights()
print(weights)

model.fit(np.array(x), np.array(y),
          batch_size=int(len(x)*0.9),epochs=5000,
          )

weights = model.layers[0].get_weights()
print(weights)


predict = model.predict([data])

for i in range (10):
    t = randint(0,len(data))
    print(y[t])
    testData = x[i]
    print(model.predict( np.array([testData])))
    
plt.plot(data, predict, 'b', data , y, 'k.')
plt.show()
model.summary()